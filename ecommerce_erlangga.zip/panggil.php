<?php
     include "content.html";
     include "footer.html";
     include "navbar.html";

?>     